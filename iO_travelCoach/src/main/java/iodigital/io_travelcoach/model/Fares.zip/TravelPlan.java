package iodigital.io_travelcoach.model;

public class TravelPlan {
}
