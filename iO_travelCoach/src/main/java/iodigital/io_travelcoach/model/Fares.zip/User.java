package iodigital.io_travelcoach.model;

public class User {
    //Need basic user info that would be relevant for transportation


}
