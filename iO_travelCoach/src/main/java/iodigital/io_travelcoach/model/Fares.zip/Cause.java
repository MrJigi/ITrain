package iodigital.io_travelcoach.model;

public class Cause {
    private String label;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
